Flutter Job-App

This project consists of four screens, 3 onboarding and 1 homesreen

if you found this project useful, then please consider giving it a star on Github

![image](https://user-images.githubusercontent.com/61144249/127092855-ca3b2d41-bdfb-4b95-8e6e-10b8b17d8e04.png)
![homescreen_mockup](https://user-images.githubusercontent.com/61144249/127093470-8381595d-4e34-4f12-a4e4-77f658b342fd.png)
